// public/main.js

document.addEventListener('DOMContentLoaded', () => {
    // --- GLOBAL STATE ---
    const STATE = {
        isLoggedIn: false,
        username: null,
        email: null, // To store user's email
        cart: {},
        allProducts: {},
    };

    // --- DOM ELEMENT SELECTOR (lazy loads elements) ---
    const DOM = new Proxy({}, {
        get: (target, prop) => {
            if (!target[prop]) {
                target[prop] = document.getElementById(prop.replace(/_/g, '-'));
            }
            return target[prop];
        }
    });
    
    // --- DYNAMIC UI TEMPLATES ---
    const MODAL_HTML = `
        <div id="cart-modal" class="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex justify-end hidden z-50">
            <div class="bg-gray-800 text-white w-full max-w-md h-full flex flex-col shadow-2xl">
                <div class="flex items-center justify-between p-6 border-b border-gray-700">
                    <h2 class="text-2xl font-bold">Your Cart</h2>
                    <button id="close-cart-btn" class="text-2xl">&times;</button>
                </div>
                <div id="cart-items-container" class="flex-grow p-6">
                    </div>
                <div class="p-6 border-t border-gray-700 space-y-4">
                    <div class="flex justify-between items-center text-lg">
                        <span class="font-semibold">Total:</span>
                        <span id="cart-total" class="font-bold text-xl">₹0.00</span>
                    </div>
                    <a href="/orders.html" id="my-orders-btn" class="block w-full text-center bg-gray-600 hover:bg-gray-500 text-white font-bold py-3 rounded-lg transition">My Orders</a>
                    <button id="checkout-btn" class="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-3 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed">Checkout</button>
                </div>
            </div>
        </div>

        <div id="auth-modal" class="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center hidden z-50 p-4">
            <div class="bg-gray-800 rounded-2xl shadow-xl w-full max-w-md relative p-8">
                <button id="close-auth-modal-btn" class="absolute top-4 right-4 text-gray-400 hover:text-white text-2xl">&times;</button>
                
                <div id="login-form-container">
                    <h2 class="text-3xl font-bold text-center mb-6">Login</h2>
                    <form id="login-form" novalidate>
                        <div class="mb-4">
                            <label for="login-email" class="block text-sm font-medium text-gray-300 mb-1">Email</label>
                            <input type="email" name="email" id="login-email" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                        </div>
                        <div class="mb-6">
                            <label for="login-password" class="block text-sm font-medium text-gray-300 mb-1">Password</label>
                            <input type="password" name="password" id="login-password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                        </div>
                        <button type="submit" class="w-full bg-yellow-500 text-black font-bold py-2 rounded-lg hover:bg-yellow-600 transition">Login</button>
                    </form>
                    <div class="my-4 text-center text-gray-400">or</div>
                    <div id="g_id_signin_container"><div id="g_id_signin"></div></div>
                    <p class="text-center mt-4">Don't have an account? <button id="show-register-form" class="text-yellow-400 hover:underline font-semibold">Sign up</button></p>
                </div>

                <div id="register-form-container" class="hidden">
                     <h2 class="text-3xl font-bold text-center mb-6">Create Account</h2>
                    <form id="register-form" novalidate>
                        <div class="mb-4">
                            <label for="register-username" class="block text-sm font-medium text-gray-300 mb-1">Full Name</label>
                            <input type="text" name="username" id="register-username" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                        </div>
                        <div class="mb-4">
                            <label for="register-email" class="block text-sm font-medium text-gray-300 mb-1">Email</label>
                            <input type="email" name="email" id="register-email" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                        </div>
                        <div class="mb-6">
                            <label for="register-password" class="block text-sm font-medium text-gray-300 mb-1">Password</label>
                            <input type="password" name="password" id="register-password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                        </div>
                        <button type="submit" class="w-full bg-yellow-500 text-black font-bold py-2 rounded-lg hover:bg-yellow-600 transition">Create Account</button>
                    </form>
                    <div class="my-4 text-center text-gray-400">or</div>
                    <div id="g_id_signin_register_container"><div id="g_id_signin_register"></div></div>
                    <p class="text-center mt-4">Already have an account? <button id="show-login-form" class="text-yellow-400 hover:underline font-semibold">Log in</button></p>
                </div>
                 <p id="auth-error-msg" class="text-red-500 text-center mt-4 h-5"></p>
            </div>
        </div>

        <div id="profile-modal" class="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex justify-end hidden z-50">
            <div class="bg-gray-800 text-white w-full max-w-md h-full flex flex-col shadow-2xl">
                <div class="flex items-center justify-between p-6 border-b border-gray-700">
                    <h2 class="text-2xl font-bold">My Profile</h2>
                    <button id="close-profile-modal-btn" class="text-2xl">&times;</button>
                </div>
                <div class="flex-grow p-6 overflow-y-auto">
                    <form id="profile-form" novalidate>
                        <div class="space-y-4">
                            <div>
                                <label for="profile-name" class="block text-sm font-medium text-gray-300 mb-1">Full Name</label>
                                <input type="text" id="profile-name" name="username" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                            </div>
                            <div>
                                <label for="profile-email" class="block text-sm font-medium text-gray-300 mb-1">Email Address</label>
                                <input type="email" id="profile-email" name="email" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                            </div>
                            <hr class="border-gray-600 my-6">
                            <h3 class="text-xl font-bold">Change Password</h3>
                            <div>
                                <label for="current-password" class="block text-sm font-medium text-gray-300 mb-1">Current Password</label>
                                <input type="password" id="current-password" name="currentPassword" placeholder="Leave blank to keep unchanged" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                            </div>
                            <div>
                                <label for="new-password" class="block text-sm font-medium text-gray-300 mb-1">New Password</label>
                                <input type="password" id="new-password" name="newPassword" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                            </div>
                        </div>
                    </form>
                    <p id="profile-msg" class="text-center mt-4 h-5"></p>
                </div>
                <div class="p-6 border-t border-gray-700">
                    <button type="submit" form="profile-form" class="w-full bg-yellow-500 text-black font-bold py-3 rounded-lg hover:bg-yellow-600 transition">Save Changes</button>
                </div>
            </div>
        </div>

        <div id="delivery-modal" class="hidden fixed inset-0 bg-black/70 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
            <div class="bg-gray-800 rounded-2xl shadow-xl w-full max-w-lg relative p-8">
                <button id="close-delivery-modal-btn" class="absolute top-4 right-4 text-gray-400 hover:text-white text-2xl">&times;</button>
                <h2 class="text-3xl font-bold text-center mb-6">Recipient & Delivery Details</h2>
                <p class="text-center text-gray-400 mb-6">Please provide your details for delivery and order confirmation.</p>
                <form id="delivery-form" class="space-y-4" novalidate>
                    <input type="text" name="fullName" placeholder="Full Name" required class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                    <input type="text" name="address" placeholder="Address (House/Flat, Street)" required class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                    <div class="grid grid-cols-2 gap-4">
                        <input type="text" name="city" placeholder="City" required class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                        <input type="text" name="state" placeholder="State" required class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <input type="text" name="country" placeholder="Country" value="India" required class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                        <input type="text" name="postalCode" placeholder="Postal Code" required class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                    </div>
                    <input type="tel" name="contactNumber" placeholder="Contact Number (for delivery)" required class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                    <input type="email" name="email" placeholder="Email Address (for receipt)" required class="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                    <button type="submit" class="w-full mt-4 bg-yellow-500 text-black font-bold py-3 rounded-lg hover:bg-yellow-600 transition">Proceed to Payment</button>
                </form>
            </div>
        </div>

        <div id="payment-success-modal" class="hidden fixed inset-0 bg-black/70 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
            <div class="bg-gray-800 rounded-2xl shadow-xl w-full max-w-sm text-center p-8">
                <h2 class="text-3xl font-bold text-green-500 mb-4">Payment Successful!</h2>
                <p class="text-gray-300 mb-6">Your order has been placed. You can view the details in the "My Orders" section.</p>
                <button id="close-success-modal-btn" class="w-full bg-yellow-500 text-black font-bold py-2 rounded-lg hover:bg-yellow-600 transition">Great!</button>
            </div>
        </div>
    `;

    const renderSharedUI = () => {
        const placeholder = document.getElementById('modal-placeholders');
        if (placeholder) {
            placeholder.innerHTML = MODAL_HTML;
        } else {
            console.error('Fatal: The #modal-placeholders element was not found in the HTML.');
        }
    };

    // --- API & HELPERS ---
    const fetchAPI = async (endpoint, options = {}) => {
        try {
            const response = await fetch(endpoint, options);
            if (!response.ok) {
                const errorResult = await response.json();
                throw new Error(errorResult.message || `HTTP error! Status: ${response.status}`);
            }
            return response.json();
        } catch (error) {
            console.error(`API call to ${endpoint} failed:`, error);
            throw error;
        }
    };

    const loadDataFromSession = (key, defaultValue) => {
        const savedData = sessionStorage.getItem(key);
        return savedData ? JSON.parse(savedData) : defaultValue;
    };

    const saveDataToSession = (key, data) => {
        sessionStorage.setItem(key, JSON.stringify(data));
    };

    const injectGlobalStyles = () => {
        const style = document.createElement('style');
        style.innerHTML = `
            .mobile-nav-link.active {
                color: #daa520;
            }
        `;
        document.head.appendChild(style);
    };

    // --- CART LOGIC ---
    const updateCart = (newCart) => {
        STATE.cart = newCart || {};
        saveDataToSession('mickyMoneyCart', STATE.cart);
        updateCartUI();
        if (STATE.isLoggedIn) {
            fetchAPI('/api/cart', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ cart: STATE.cart })
            }).catch(err => console.error("Failed to sync cart with server:", err));
        }
    };

    const addToCart = (productId, quantity = 1) => {
        if (!STATE.isLoggedIn) {
            openAuthModal('login');
            return false;
        }
        const newCart = { ...STATE.cart };
        newCart[productId] = (newCart[productId] || 0) + quantity;
        updateCart(newCart);
        return true;
    };

    const adjustQuantity = (productId, amount) => {
        const newCart = { ...STATE.cart };
        if (!newCart[productId]) return;
        newCart[productId] += amount;
        if (newCart[productId] <= 0) delete newCart[productId];
        updateCart(newCart);
    };

    // --- UI UPDATE LOGIC ---
    const updateHeaderUI = () => {
        const loggedIn = STATE.isLoggedIn;
        const authLinks = document.getElementById('auth-links');
        const userInfo = document.getElementById('user-info');
        if (authLinks) authLinks.style.display = loggedIn ? 'none' : 'flex';
        if (userInfo) userInfo.style.display = loggedIn ? 'flex' : 'none';
        const usernameDisplay = document.getElementById('username-display');
        const mobileUsernameDisplay = document.getElementById('mobile-username-display');
        if (loggedIn && STATE.username) {
            const firstName = STATE.username.split(' ')[0];
            if (usernameDisplay) usernameDisplay.textContent = firstName;
            if (mobileUsernameDisplay) mobileUsernameDisplay.textContent = firstName;
        } else {
            if (usernameDisplay) usernameDisplay.textContent = '';
            if (mobileUsernameDisplay) mobileUsernameDisplay.textContent = '';
        }
        const mobileAuth = document.getElementById('mobile-auth-links');
        const mobileUser = document.getElementById('mobile-user-info');
        if (mobileAuth) mobileAuth.classList.toggle('hidden', loggedIn);
        if (mobileUser) mobileUser.classList.toggle('hidden', !loggedIn);
    };

    const updateCartUI = () => {
        const cartCounts = document.querySelectorAll('.cart-count');
        const totalItems = Object.values(STATE.cart).reduce((sum, qty) => sum + qty, 0);
        cartCounts.forEach(el => {
            el.textContent = totalItems;
            el.classList.toggle('hidden', totalItems === 0);
        });
        if (DOM.cart_total) {
            let totalPrice = 0;
            for (const pId in STATE.cart) {
                if (STATE.allProducts[pId]) {
                    totalPrice += STATE.allProducts[pId].discountedPriceValue * STATE.cart[pId];
                }
            }
            DOM.cart_total.textContent = `₹${totalPrice.toFixed(2)}`;
            if (DOM.checkout_btn) DOM.checkout_btn.disabled = totalItems === 0;
            const myOrdersBtn = DOM.my_orders_btn;
            if (myOrdersBtn) {
                 myOrdersBtn.style.display = STATE.isLoggedIn ? 'block' : 'none';
            }
        }
        renderCartItems();
    };
    
    const renderCartItems = () => {
        if (!DOM.cart_items_container) return;
        const cartKeys = Object.keys(STATE.cart);

        if (cartKeys.length === 0) {
            DOM.cart_items_container.innerHTML = `<p id="empty-cart-msg" class="text-gray-400 text-center mt-8">Your cart is empty.</p>`;
            DOM.cart_items_container.style.overflowY = 'hidden';
        } else {
            DOM.cart_items_container.innerHTML = cartKeys.map(pId => {
                const product = STATE.allProducts[pId];
                if (!product) return '';
                const quantity = STATE.cart[pId];
                const imageUrl = product.image.startsWith('http') ? product.image : `/${product.image}`;
                return `
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center min-w-0"><img src="${imageUrl}" alt="${product.name}" class="w-16 h-16 object-contain rounded-md bg-gray-700 mr-4 flex-shrink-0">
                            <div class="min-w-0"><h4 class="font-semibold truncate">${product.name}</h4><p class="text-sm text-gray-400">₹${product.discountedPriceValue.toFixed(2)}</p></div>
                        </div>
                        <div class="flex items-center gap-3 ml-2"><button class="quantity-btn decrease-qty" data-id="${pId}">-</button><span class="font-semibold">${quantity}</span><button class="quantity-btn increase-qty" data-id="${pId}">+</button></div>
                    </div>`;
            }).join('');
            DOM.cart_items_container.style.overflowY = 'auto';
        }
    };

    const setActiveNavLink = () => {
        const pathname = window.location.pathname;
    
        let currentPage = 'index';
        if (pathname.includes('shop')) {
            currentPage = 'shop';
        } else if (pathname.includes('products')) {
            currentPage = 'shop'; 
        } else if (pathname.includes('orders')) {
            currentPage = 'orders';
        }
    
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('text-white', 'font-semibold');
            link.classList.add('text-gray-400', 'hover:text-white');
            if (link.dataset.page === currentPage) {
                 link.classList.add('text-white', 'font-semibold');
                 link.classList.remove('text-gray-400', 'hover:text-white');
            }
        });
        
        document.querySelectorAll('.mobile-nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.dataset.page === currentPage) {
                link.classList.add('active');
            }
        });
    };

    // --- AUTH LOGIC ---
    const renderGoogleButtons = () => {
        if (typeof google !== 'undefined') {
            const loginContainer = document.getElementById('g_id_signin');
            if (loginContainer) {
                google.accounts.id.renderButton(loginContainer, { theme: "outline", size: "large", width: "100%" });
            }
            const registerContainer = document.getElementById('g_id_signin_register');
            if (registerContainer) {
                google.accounts.id.renderButton(registerContainer, { theme: "outline", size: "large", width: "100%" });
            }
        }
    };

    const openAuthModal = (view = 'login') => {
        if (DOM.auth_error_msg) DOM.auth_error_msg.textContent = '';
        if (DOM.login_form_container) DOM.login_form_container.classList.toggle('hidden', view !== 'login');
        if (DOM.register_form_container) DOM.register_form_container.classList.toggle('hidden', view !== 'register');
        if (DOM.auth_modal) DOM.auth_modal.classList.remove('hidden');
        renderGoogleButtons();
    };
    
    const closeAuthModal = () => {
        if (DOM.auth_modal) DOM.auth_modal.classList.add('hidden');
        if (DOM.login_form) DOM.login_form.reset();
        if (DOM.register_form) DOM.register_form.reset();
    };

    const openProfileModal = () => {
        if (!DOM.profile_modal) return;
        if (DOM.profile_msg) DOM.profile_msg.textContent = '';
        if (DOM.profile_form) DOM.profile_form.reset();
        
        if (DOM.profile_name) DOM.profile_name.value = STATE.username || '';
        if (DOM.profile_email) DOM.profile_email.value = STATE.email || '';
        
        DOM.profile_modal.classList.remove('hidden');
    };

    const closeProfileModal = () => {
        if(DOM.profile_modal) DOM.profile_modal.classList.add('hidden');
    };

    const handleSuccessfulLogin = (loginData) => {
        STATE.isLoggedIn = true;
        STATE.username = loginData.username;
        STATE.email = loginData.email;
        const guestCart = loadDataFromSession('mickyMoneyCart', {});
        const serverCart = loginData.cart || {};
        const mergedCart = { ...guestCart, ...serverCart };
        updateCart(mergedCart);
        closeAuthModal();
        updateHeaderUI();
    };
    
    const handleLogout = async () => {
        try {
            await fetchAPI('/api/logout', { method: 'POST' });
        } catch (error) {
            console.error("Logout failed:", error);
        } finally {
            STATE.isLoggedIn = false;
            STATE.username = null;
            STATE.email = null;
            updateCart({});
            updateHeaderUI();
            window.location.reload(); 
        }
    };

    window.handleGoogleCredentialResponse = async (googleUser) => {
        try {
            const result = await fetchAPI('/api/auth/google', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: googleUser.credential })
            });
            handleSuccessfulLogin(result);
        } catch (error) {
            if (DOM.auth_error_msg) DOM.auth_error_msg.textContent = error.message || 'Google Sign-In failed.';
        }
    };

    const initializeGoogleSignIn = () => {
        if (typeof google !== 'undefined') {
            const clientIdMeta = document.querySelector('meta[name="google-signin-client_id"]');
            if (clientIdMeta && clientIdMeta.content) {
                 google.accounts.id.initialize({
                    client_id: clientIdMeta.content,
                    callback: handleGoogleCredentialResponse,
                });
            }
        }
    };
    
    // --- PAGE-SPECIFIC INITIALIZATION ---
    const initHomePage = () => {
        const thumbnailContainer = DOM.thumbnail_container;
        if (!thumbnailContainer) return;
        let currentProductId = 'dryer-01';
        if (STATE.allProducts && Object.keys(STATE.allProducts).length > 0) {
            currentProductId = Object.keys(STATE.allProducts)[0];
        }

        const displayProduct = (productId) => {
            const product = STATE.allProducts[productId];
            if (!product) return;
            currentProductId = productId;
            const imageUrl = product.image.startsWith('http') ? product.image : `/${product.image}`;
            if(DOM.main_product_image) DOM.main_product_image.src = imageUrl;
            if(DOM.product_name) DOM.product_name.textContent = product.name;
            if (DOM.product_description) DOM.product_description.textContent = product.description;
            if(DOM.main_price_container) DOM.main_price_container.innerHTML = `<span class="original-price">₹${product.priceValue.toFixed(0)}</span> <span class="discount-price">₹${product.discountedPriceValue.toFixed(0)}</span> <span class="discount-text">${product.discount}% Off</span>`;
        };
        thumbnailContainer.addEventListener('click', (e) => {
            const btn = e.target.closest('.thumbnail');
            if (btn) {
                thumbnailContainer.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
                btn.classList.add('active');
                displayProduct(btn.dataset.productId);
            }
        });
        if (DOM.add_to_cart_btn) {
            DOM.add_to_cart_btn.addEventListener('click', () => {
                const success = addToCart(currentProductId, 1);
                if (success) {
                    DOM.add_to_cart_btn.textContent = 'Added!';
                    setTimeout(() => DOM.add_to_cart_btn.textContent = 'Add to cart', 1500);
                }
            });
        }
        displayProduct(currentProductId);
        const firstThumbnail = thumbnailContainer.querySelector(`[data-product-id="${currentProductId}"]`);
        if(firstThumbnail) firstThumbnail.classList.add('active');
    };

    const initShopPage = () => {
        const grid = DOM.product_grid;
        if (!grid) return;
        const categoryFilters = DOM.category_filters;
        let currentCategory = 'All';
        let currentSearchTerm = '';
        const renderProducts = () => {
            const filteredProducts = Object.values(STATE.allProducts).filter(product => {
                const matchesCategory = currentCategory === 'All' || product.category === currentCategory;
                const matchesSearch = currentSearchTerm === '' || product.name.toLowerCase().includes(currentSearchTerm);
                return matchesCategory && matchesSearch;
            });
            if (filteredProducts.length > 0) {
                grid.innerHTML = filteredProducts.map(product => {
                    const imageUrl = product.image.startsWith('http') ? product.image : `/${product.image}`;
                    return `
                    <a href="/products/${product.id}" class="product-item">
                        <div class="product-image-card"><div class="discount-badge">${product.discount}% OFF</div><div class="image-wrapper"><img src="${imageUrl}" alt="${product.name}"></div></div>
                        <div class="product-details"><h4 class="product-title text-lg">${product.name}</h4><div class="price-container"><span class="original-price">₹${product.priceValue.toFixed(0)}</span><span class="discount-price">₹${product.discountedPriceValue.toFixed(0)}</span></div></div>
                    </a>`;
                }).join('');
            } else {
                grid.innerHTML = `<div class="col-span-full text-center py-16"><h3 class="text-2xl font-semibold">No products found</h3><p class="text-gray-400">Try adjusting your search or category filters.</p></div>`;
            }
        };
        if (categoryFilters) {
            const categories = ['All', ...new Set(Object.values(STATE.allProducts).map(p => p.category).filter(Boolean))];
            categoryFilters.innerHTML = categories.map((cat, i) => `<button class="category-btn whitespace-nowrap px-4 py-2 text-sm font-semibold rounded-lg transition ${i === 0 ? 'bg-yellow-500 text-black' : 'bg-gray-700 hover:bg-gray-600'}" data-category="${cat}">${cat}</button>`).join('');
            
            categoryFilters.addEventListener('click', e => {
                const button = e.target.closest('.category-btn');
                if (!button) return;

                categoryFilters.querySelectorAll('.category-btn').forEach(btn => {
                    btn.classList.remove('bg-yellow-500', 'text-black');
                    btn.classList.add('bg-gray-700', 'hover:bg-gray-600');
                });
                button.classList.add('bg-yellow-500', 'text-black');
                button.classList.remove('bg-gray-700', 'hover:bg-gray-600');
                
                currentCategory = button.dataset.category;
                renderProducts();
            });
        }
        DOM.search_bar?.addEventListener('input', e => {
            currentSearchTerm = e.target.value.toLowerCase();
            renderProducts();
        });
        renderProducts();

        const header = document.querySelector('header');
        if (header) {
            let lastScrollY = window.scrollY;
            window.addEventListener('scroll', () => {
                const isMobile = window.innerWidth < 768;
                if (isMobile) {
                    if (window.scrollY > lastScrollY && window.scrollY > 150) {
                        header.style.transform = 'translateY(-110%)';
                        header.style.transition = 'transform 0.3s ease-in-out';
                    } else {
                        header.style.transform = 'translateY(0)';
                    }
                    lastScrollY = window.scrollY < 0 ? 0 : window.scrollY;
                } else {
                    header.style.transform = 'translateY(0)';
                }
            });
        }
    };

    const initProductPage = async () => {
        const pathParts = window.location.pathname.split('/');
        const productId = pathParts[pathParts.length - 1];
        if (!productId || !document.getElementById('product-section')) return;

        let currentQuantity = 1;

        const renderReviews = (reviews) => {
            if (!DOM.reviews_list) return;
            if (reviews && reviews.length > 0) {
                if (DOM.no_reviews_msg) DOM.no_reviews_msg.classList.add('hidden');
                DOM.reviews_list.innerHTML = reviews.map(review => {
                    const stars = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
                    const reviewDate = new Date(review.created_at).toLocaleDateString();
                    return `
                        <div class="bg-gray-700/50 p-4 rounded-xl">
                            <div class="flex items-center justify-between mb-2">
                                <h5 class="font-bold text-white">${review.username}</h5>
                                <span class="text-sm text-gray-400">${reviewDate}</span>
                            </div>
                            <div class="text-yellow-400 mb-2">${stars}</div>
                            <p class="text-gray-300">${review.comment || ''}</p>
                        </div>`;
                }).join('');
            } else {
                if (DOM.no_reviews_msg) DOM.no_reviews_msg.classList.remove('hidden');
                DOM.reviews_list.innerHTML = '';
            }
        };

        const loadProductData = async () => {
            try {
                const data = await fetchAPI(`/api/products/${productId}`);
                const { product, reviews } = data;
                const discountedPrice = product.price * (1 - product.discount / 100);

                const imageUrl = product.image.startsWith('http') ? product.image : `/${product.image}`;
                if (DOM.main_product_image) DOM.main_product_image.src = imageUrl;

                if (DOM.main_product_image) DOM.main_product_image.alt = product.name;
                if (DOM.product_name) DOM.product_name.textContent = product.name;
                if (DOM.product_description) DOM.product_description.textContent = product.description;
                if (DOM.price_container) DOM.price_container.innerHTML = `
                    <span class="text-gray-400 line-through text-2xl">₹${product.price.toFixed(0)}</span>
                    <span class="text-white">₹${discountedPrice.toFixed(0)}</span>
                `;
                renderReviews(reviews);
                if (DOM.product_section) DOM.product_section.classList.remove('opacity-0');

            } catch (error) {
                console.error('Failed to load product details:', error);
                if (DOM.product_section) {
                    DOM.product_section.innerHTML = `<div class="text-center py-10"><h2 class="text-2xl text-red-500">Product Not Found</h2><p class="text-gray-400">The product you are looking for does not exist. <a href="/shop" class="text-yellow-400 underline">Go to shop</a></p></div>`;
                    DOM.product_section.classList.remove('opacity-0');
                }
            }
        };
        
        if (DOM.decrease_qty) DOM.decrease_qty.addEventListener('click', () => {
            if (currentQuantity > 1) {
                currentQuantity--;
                DOM.quantity.textContent = currentQuantity;
            }
        });

        if (DOM.increase_qty) DOM.increase_qty.addEventListener('click', () => {
            currentQuantity++;
            DOM.quantity.textContent = currentQuantity;
        });

        if (DOM.add_to_cart_btn) {
            DOM.add_to_cart_btn.addEventListener('click', () => {
                const success = addToCart(productId, currentQuantity);
                if (success) {
                    DOM.add_to_cart_btn.textContent = 'Added!';
                    DOM.add_to_cart_btn.classList.add('added');
                    setTimeout(() => {
                        DOM.add_to_cart_btn.textContent = 'Add to Cart';
                        DOM.add_to_cart_btn.classList.remove('added');
                    }, 2000);
                }
            });
        }
        
        if (DOM.review_form) DOM.review_form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = DOM.review_username.value;
            const comment = DOM.review_comment.value;
            const rating = DOM.review_form.querySelector('input[name="rating"]:checked')?.value;

            if (!username || !rating) {
                alert('Please provide a name and a star rating.');
                return;
            }

            try {
                await fetchAPI('/api/reviews', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ productId, username, rating, comment })
                });
                DOM.review_form.reset();
                loadProductData();
            } catch (error) {
                alert(`Error submitting review: ${error.message}`);
            }
        });
        
        loadProductData();
    };

    const initiatePayment = async (recipientDetails) => {
        try {
            const { success, order, key, message } = await fetchAPI('/api/orders/create', { method: 'POST' });

            if (!success) {
                alert(`Error: ${message}`);
                return;
            }

            const options = {
                key,
                amount: order.amount,
                currency: "INR",
                name: "Micky Money",
                description: "Premium Styling Tools",
                order_id: order.id,
                handler: async function (response) {
                    const verificationData = {
                        razorpay_payment_id: response.razorpay_payment_id,
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_signature: response.razorpay_signature,
                        recipientDetails
                    };

                    const verifyResult = await fetchAPI('/api/orders/verify', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(verificationData)
                    });
                    
                    if (verifyResult.success) {
                        DOM.delivery_modal.classList.add('hidden');
                        DOM.cart_modal.classList.add('hidden');
                        DOM.payment_success_modal.classList.remove('hidden');
                        updateCart({}); // Clear the cart in the state
                    } else {
                        alert(`Payment verification failed: ${verifyResult.message}`);
                    }
                },
                prefill: {
                    name: recipientDetails.fullName,
                    email: recipientDetails.email,
                    contact: recipientDetails.contactNumber
                },
                theme: {
                    color: "#daa520"
                }
            };
            const rzp1 = new Razorpay(options);
            rzp1.open();

        } catch (error) {
            console.error(error);
            alert('Could not initiate payment. Please try again.');
        }
    };
    
    const initOrdersPage = async () => {
        const ordersContainer = DOM.orders_container;
        if (!ordersContainer) return;

        if (!STATE.isLoggedIn) {
            ordersContainer.innerHTML = `<p class="text-center text-gray-400">Please <button id="login-for-orders" class="text-yellow-400 underline">log in</button> to view your orders.</p>`;
            document.getElementById('login-for-orders').addEventListener('click', () => openAuthModal('login'));
            return;
        }

        try {
            const data = await fetchAPI('/api/orders/my-orders');
            if (data.orders && data.orders.length > 0) {
                ordersContainer.innerHTML = data.orders.map(order => {
                    const products = JSON.parse(order.product_details);
                    const orderDate = new Date(order.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
                    
                    // ✅ FIX: This logic ensures tracking links are treated as absolute URLs
                    const trackingLink = order.tracking_link;
                    let trackingLinkHtml = `<p class="text-gray-400">Tracking link will be available soon.</p>`;
                    if (trackingLink) {
                        // Ensure it's an absolute URL
                        const trackingUrl = (trackingLink.startsWith('http://') || trackingLink.startsWith('https://')) 
                            ? trackingLink 
                            : `//${trackingLink}`;
                        trackingLinkHtml = `<a href="${trackingUrl}" target="_blank" rel="noopener noreferrer" class="text-yellow-400 hover:underline break-all">${trackingLink}</a>`;
                    }


                    return `
                    <div class="glass-card p-6 rounded-2xl">
                        <div class="flex flex-col md:flex-row justify-between md:items-center border-b border-gray-700 pb-4 mb-4">
                            <div>
                                <p class="text-sm text-gray-400">Order Date: <span class="text-gray-200 font-medium">${orderDate}</span></p>
                                <p class="text-sm text-gray-400">Order ID: <span class="text-gray-200 font-medium break-all">${order.razorpay_order_id}</span></p>
                            </div>
                            <div class="mt-4 md:mt-0 text-left md:text-right">
                                <p class="text-lg font-bold text-white">Amount Paid: ₹${(order.amount_in_paise / 100).toFixed(2)}</p>
                                <span class="text-sm font-semibold px-3 py-1 rounded-full ${order.status === 'delivered' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'}">${order.status === 'delivered' ? 'Delivered' : 'On the Way'}</span>
                            </div>
                        </div>

                        <h4 class="font-bold text-lg mb-4">Items Ordered</h4>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                            ${products.map(p => `
                                <div class="flex items-center bg-gray-800/50 p-3 rounded-lg">
                                    <img src="/${p.image}" class="w-16 h-16 object-contain rounded-md bg-gray-700 mr-4">
                                    <div class="flex-grow">
                                        <p class="font-semibold text-white leading-tight">${p.name}</p>
                                        <p class="text-sm text-gray-400">Qty: ${p.quantity}</p>
                                    </div>
                                    <p class="ml-4 font-medium text-gray-300">₹${(p.pricePerItem * p.quantity).toFixed(2)}</p>
                                </div>
                            `).join('')}
                        </div>
                        
                        <div class="border-t border-gray-700 pt-4">
                             <h4 class="font-bold text-lg mb-2">Tracking Link</h4>
                             ${trackingLinkHtml}
                        </div>
                    </div>
                    `;
                }).join('');
            } else {
                ordersContainer.innerHTML = `<p class="text-center text-gray-400">You haven't placed any orders yet. <a href="/shop.html" class="text-yellow-400 underline">Start shopping!</a></p>`;
            }
        } catch (error) {
            ordersContainer.innerHTML = `<p class="text-center text-red-500">Failed to load your orders. Please try again later.</p>`;
        }
    };

    // --- GLOBAL EVENT LISTENERS & INITIALIZATION ---
    const addGlobalListeners = () => {
        document.body.addEventListener('click', (e) => {
            const target = e.target;
            const button = target.closest('button');
            
            if (target.closest('.cart-trigger')) {
                if (DOM.cart_modal) DOM.cart_modal.classList.remove('hidden');
                return;
            }

            if (button?.id === 'close-cart-btn' || target.id === 'cart-modal') {
                if (DOM.cart_modal) DOM.cart_modal.classList.add('hidden');
            }
            if (button?.id === 'close-auth-modal-btn' || target.id === 'auth-modal') {
                closeAuthModal();
            }
            if (button?.id === 'close-profile-modal-btn' || target.id === 'profile-modal') {
                closeProfileModal();
            }
            if (button?.id === 'profile-trigger' || button?.id === 'mobile-profile-trigger') {
                if (STATE.isLoggedIn) {
                    openProfileModal();
                } else {
                    openAuthModal('login');
                }
            }
            if (button?.id === 'close-menu-btn') {
                if (DOM.mobile_menu) DOM.mobile_menu.classList.add('hidden');
            }
            if (button?.id.includes('-trigger')) {
                if (DOM.mobile_menu) DOM.mobile_menu.classList.add('hidden');
                if (button.id.startsWith('login') || button.id.startsWith('mobile-login')) openAuthModal('login');
                if (button.id.startsWith('register') || button.id.startsWith('mobile-register')) openAuthModal('register');
            }
            if (button?.id === 'show-register-form') openAuthModal('register');
            if (button?.id === 'show-login-form') openAuthModal('login');
            if (button?.id === 'logout-btn' || button?.id === 'mobile-logout-btn') handleLogout();
            if (button?.id === 'open-menu-btn') {
                if (DOM.mobile_menu) DOM.mobile_menu.classList.remove('hidden');
            }
            if (button?.classList.contains('decrease-qty')) adjustQuantity(button.dataset.id, -1);
            if (button?.classList.contains('increase-qty')) adjustQuantity(button.dataset.id, 1);

            if (button?.id === 'checkout-btn') {
                if (Object.keys(STATE.cart).length === 0) {
                    alert('Your cart is empty.');
                    return;
                }
                if(DOM.delivery_modal) {
                    const emailInput = DOM.delivery_modal.querySelector('input[name="email"]');
                    if (emailInput && STATE.email) {
                        emailInput.value = STATE.email;
                    }
                    DOM.delivery_modal.classList.remove('hidden');
                }
            }

            if (button?.id === 'close-delivery-modal-btn' || target.id === 'delivery-modal') {
                if(DOM.delivery_modal) DOM.delivery_modal.classList.add('hidden');
            }

            if (button?.id === 'close-success-modal-btn' || target.id === 'payment-success-modal') {
                if(DOM.payment_success_modal) DOM.payment_success_modal.classList.add('hidden');
            }
        });

        const modalPlaceholders = DOM.modal_placeholders;
        if (modalPlaceholders) {
             modalPlaceholders.addEventListener('submit', async e => {
                e.preventDefault();
                const form = e.target;
                const data = Object.fromEntries(new FormData(form).entries());
                
                try {
                    if (form.id === 'login-form') {
                        if (DOM.auth_error_msg) DOM.auth_error_msg.textContent = '';
                        const result = await fetchAPI('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
                        handleSuccessfulLogin(result);

                    } else if (form.id === 'register-form') {
                        if (DOM.auth_error_msg) DOM.auth_error_msg.textContent = '';
                        await fetchAPI('/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
                        alert('Registration successful! Please log in.');
                        openAuthModal('login');

                    } else if (form.id === 'profile-form') {
                        if (DOM.profile_msg) DOM.profile_msg.textContent = '';
                        const result = await fetchAPI('/api/user/profile', {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(data)
                        });

                        STATE.username = result.username;
                        STATE.email = result.email;
                        updateHeaderUI();

                        if (DOM.profile_msg) {
                            DOM.profile_msg.textContent = 'Profile updated successfully!';
                            DOM.profile_msg.classList.remove('text-red-500');
                            DOM.profile_msg.classList.add('text-green-500');
                        }
                        setTimeout(() => {
                            closeProfileModal();
                           if (DOM.profile_msg) DOM.profile_msg.textContent = '';
                        }, 2000);
                    
                    } else if (form.id === 'delivery-form') {
                        const recipientDetails = data;
                        initiatePayment(recipientDetails);
                    }
                } catch (error) {
                    if (form.id === 'profile-form') {
                        if (DOM.profile_msg) {
                            DOM.profile_msg.textContent = error.message;
                            DOM.profile_msg.classList.remove('text-green-500');
                            DOM.profile_msg.classList.add('text-red-500');
                        }
                    } else {
                       if (DOM.auth_error_msg) DOM.auth_error_msg.textContent = error.message;
                    }
                }
            });
        }
    };

    const initApp = async () => {
        renderSharedUI();
        injectGlobalStyles();
        try {
            const products = await (await fetch('/products.json')).json();
            STATE.allProducts = products.reduce((acc, p) => {
                const priceValue = parseFloat(p.price.replace('₹', ''));
                acc[p.id] = { ...p, priceValue, discountedPriceValue: priceValue * (1 - p.discount / 100) };
                return acc;
            }, {});
        } catch (e) {
            console.error("Fatal: Could not load product data.");
            document.body.innerHTML = '<p style="color:red; text-align:center; padding-top: 2rem;">Could not load product data.</p>';
            return;
        }
        
        const sessionData = await fetchAPI('/api/session').catch(() => ({ isLoggedIn: false, username: null, email: null, cart: {} }));
        STATE.isLoggedIn = sessionData.isLoggedIn;
        STATE.username = sessionData.username;
        STATE.email = sessionData.email;
        const cartSource = STATE.isLoggedIn ? sessionData.cart : loadDataFromSession('mickyMoneyCart', {});
        updateCart(cartSource);

        updateHeaderUI();
        setActiveNavLink();
        initializeGoogleSignIn();
        addGlobalListeners();

        const pathname = window.location.pathname;
        if (pathname === '/' || pathname.endsWith('index.html') || pathname === '') {
            initHomePage();
        } else if (pathname.startsWith('/shop')) {
            initShopPage();
        } else if (pathname.startsWith('/products/')) {
            initProductPage();
        } else if (pathname.startsWith('/orders')) {
            initOrdersPage();
        }  
    };

    initApp();
});
