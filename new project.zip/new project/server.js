// server.js

// --- MODULE IMPORTS ---
const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const fsp = require('fs').promises;
const session = require('express-session');
const LokiStore = require('connect-loki')(session);
const bcrypt = require('bcrypt');
const { OAuth2Client } = require('google-auth-library');
const Razorpay = require('razorpay');
const crypto = require('crypto');

const app = express();

// --- CONFIGURATION ---
const PORT = process.env.PORT || 3000;
const GOOGLE_CLIENT_ID = '508302397803-65nlhvp2k57tacgsbhbk1gg184lq2th3.apps.googleusercontent.com';
const client = new OAuth2Client(GOOGLE_CLIENT_ID);
const SALT_ROUNDS = 10;
const RAZORPAY_KEY_ID = 'rzp_test_RQIHqFP4PV0qZP'; 
const RAZORPAY_KEY_SECRET = 'RdsQHGlN0tI3uFIICSNBd6uD';

const razorpay = new Razorpay({
    key_id: RAZORPAY_KEY_ID,
    key_secret: RAZORPAY_KEY_SECRET,
});

// --- ASYNC DB HELPER FUNCTIONS ---
const dbGet = (sql, params = []) =>
  new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));

const dbAll = (sql, params = []) =>
    new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));

const dbRun = (sql, params = []) =>
  new Promise((resolve, reject) => db.run(sql, params, function (err) {
    err ? reject(err) : resolve(this);
  }));

// --- DATABASE SETUP ---
const dbPath = path.join(__dirname, 'database.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Fatal Error: Could not open database.', err.message);
  } else {
    console.log('✅ Connected to SQLite database.');
    initializeDb().catch(err => {
        console.error("Failed to initialize database:", err);
    });
  }
});

async function initializeDb() {
    try {
        await dbRun(`CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT, price REAL NOT NULL, discount INTEGER, image TEXT, description TEXT)`);
        await dbRun(`CREATE TABLE IF NOT EXISTS reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id TEXT NOT NULL, username TEXT NOT NULL, rating INTEGER NOT NULL, comment TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (product_id) REFERENCES products(id))`);
        await dbRun(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password TEXT, google_id TEXT UNIQUE, cart TEXT)`);
        
        await dbRun(`
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, razorpay_order_id TEXT NOT NULL, razorpay_payment_id TEXT NOT NULL,
                razorpay_signature TEXT NOT NULL, amount_in_paise INTEGER NOT NULL, status TEXT DEFAULT 'paid', recipient_details TEXT NOT NULL,
                product_details TEXT NOT NULL, tracking_link TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `);
        
        await dbRun(`
            CREATE TABLE IF NOT EXISTS admin (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
        `);
        
        const adminUser = await dbGet('SELECT * FROM admin WHERE username = ?', ['admin']);
        if (!adminUser) {
            const hashedPassword = await bcrypt.hash('adminpassword123', SALT_ROUNDS);
            await dbRun('INSERT INTO admin (username, password) VALUES (?, ?)', ['admin', hashedPassword]);
            console.log('✅ Default admin user created. (Username: admin, Password: adminpassword123)');
        }
        
        const row = await dbGet('SELECT COUNT(*) as count FROM products');
        if (row && row.count === 0) {
            console.log('📦 Populating products table from products.json...');
            const data = await fsp.readFile(path.join(__dirname, 'public', 'products.json'), 'utf8');
            const products = JSON.parse(data);
            const insertSql = `INSERT INTO products (id, name, category, price, discount, image, description) VALUES (?, ?, ?, ?, ?, ?, ?)`;
            await dbRun('BEGIN TRANSACTION');
            for (const product of products) {
                const priceValue = parseFloat(product.price.replace('₹', ''));
                const desc = `Discover the ${product.name}, a top-quality ${product.category} product.`;
                await dbRun(insertSql, [product.id, product.name, product.category, priceValue, product.discount, product.image, desc]);
            }
            await dbRun('COMMIT');
            console.log('✅ Products table populated.');
        }
    } catch (err) {
        console.error('Error during database initialization:', err);
        await dbRun('ROLLBACK');
    }
}

// --- MIDDLEWARE ---
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
const sessionsDir = path.join(__dirname, 'sessions');
if (!fs.existsSync(sessionsDir)) fs.mkdirSync(sessionsDir, { recursive: true });
app.use(session({
  store: new LokiStore({ path: path.join(sessionsDir, 'sessions.db') }),
  secret: 'super_secret_micky_money_key',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

async function updateUserCartInDb(userId, cart) {
  if (!userId) return;
  try {
    await dbRun('UPDATE users SET cart = ? WHERE id = ?', [JSON.stringify(cart), userId]);
  } catch (err) {
    console.error(`Failed to update cart for user ${userId}:`, err);
  }
}

// --- USER API ROUTES ---
app.get('/api/products/:id', (req, res) => {
    const productId = req.params.id;
    db.get('SELECT * FROM products WHERE id = ?', [productId], (err, product) => {
        if (err || !product) return res.status(404).json({ message: 'Product not found' });
        db.all('SELECT username, rating, comment, created_at FROM reviews WHERE product_id = ? ORDER BY created_at DESC', [productId], (err, reviews) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ product, reviews: reviews || [] });
        });
    });
});

app.post('/api/reviews', (req, res) => {
    const { productId, username, rating, comment } = req.body;
    if (!productId || !username || !rating) return res.status(400).json({ message: 'Missing required fields.' });
    db.run('INSERT INTO reviews (product_id, username, rating, comment) VALUES (?, ?, ?, ?)', [productId, username, rating, comment], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ success: true, message: 'Review added successfully.' });
    });
});

app.post('/api/cart', (req, res) => {
    if (req.session.userId) {
        req.session.cart = req.body.cart;
        res.json({ success: true, message: 'Cart updated in session.' });
    } else {
        res.status(401).json({ success: false, message: 'User not logged in.' });
    }
});

app.post('/api/auth/register', async (req, res) => {
    const { username, email, password } = req.body;
    if (!username || !email || !password) return res.status(400).json({ message: 'All fields are required.' });
    try {
        const userExists = await dbGet('SELECT id FROM users WHERE email = ? OR username = ?', [email.toLowerCase(), username]);
        if (userExists) return res.status(409).json({ message: 'Username or email already exists.' });
        const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
        await dbRun('INSERT INTO users (username, email, password, cart) VALUES (?, ?, ?, ?)', [username, email.toLowerCase(), hashedPassword, '{}']);
        res.status(201).json({ success: true, message: 'Registration successful!' });
    } catch (err) {
        res.status(500).json({ message: 'Server error during registration.' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    const { email, username, password } = req.body;
    if ((!email && !username) || !password) return res.status(400).json({ message: 'Email or username and password are required.' });
    try {
        const identifier = email ? email.toLowerCase() : username;
        const user = await dbGet('SELECT * FROM users WHERE email = ? OR username = ?', [identifier, identifier]);
        if (!user || !user.password) return res.status(401).json({ message: 'Invalid credentials.' });
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(401).json({ message: 'Invalid credentials.' });
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.email = user.email;
        req.session.cart = JSON.parse(user.cart || '{}');
        res.status(200).json({ success: true, username: user.username, email: user.email, cart: req.session.cart });
    } catch (err) {
        res.status(500).json({ message: 'Server error during login.' });
    }
});

app.post('/api/auth/google', async (req, res) => {
    try {
        const { token } = req.body;
        const ticket = await client.verifyIdToken({ idToken: token, audience: GOOGLE_CLIENT_ID });
        const { sub: google_id, name, email } = ticket.getPayload();
        let user = await dbGet('SELECT * FROM users WHERE google_id = ? OR email = ?', [google_id, email.toLowerCase()]);
        if (user) {
            if (!user.google_id) await dbRun('UPDATE users SET google_id = ? WHERE id = ?', [google_id, user.id]);
        } else {
            const result = await dbRun('INSERT INTO users (username, email, google_id, cart) VALUES (?, ?, ?, ?)', [name, email.toLowerCase(), google_id, '{}']);
            user = { id: result.lastID, username: name, email: email.toLowerCase(), cart: '{}' };
        }
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.email = user.email;
        req.session.cart = JSON.parse(user.cart || '{}');
        res.status(200).json({ success: true, username: user.username, email: user.email, cart: req.session.cart });
    } catch (err) {
        res.status(401).json({ message: 'Invalid Google token.' });
    }
});

app.put('/api/user/profile', async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ message: 'You must be logged in to update your profile.' });
    const { username, email, currentPassword, newPassword } = req.body;
    const userId = req.session.userId;
    try {
        const existingUser = await dbGet('SELECT * FROM users WHERE (email = ? OR username = ?) AND id != ?', [email.toLowerCase(), username, userId]);
        if (existingUser) return res.status(409).json({ message: 'Username or email is already taken.' });
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [userId]);
        if (!user) return res.status(404).json({ message: 'User not found.' });
        let sql = 'UPDATE users SET username = ?, email = ?';
        const params = [username, email.toLowerCase()];
        if (newPassword) {
            if (!currentPassword) return res.status(400).json({ message: 'Current password is required to set a new password.' });
            if (!user.password) return res.status(400).json({ message: 'Cannot change password for accounts created with Google Sign-In.' });
            const isMatch = await bcrypt.compare(currentPassword, user.password);
            if (!isMatch) return res.status(401).json({ message: 'Incorrect current password.' });
            const hashedNewPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);
            sql += ', password = ?';
            params.push(hashedNewPassword);
        }
        sql += ' WHERE id = ?';
        params.push(userId);
        await dbRun(sql, params);
        req.session.username = username;
        req.session.email = email.toLowerCase();
        res.status(200).json({ success: true, username: req.session.username, email: req.session.email });
    } catch (err) {
        res.status(500).json({ message: 'Server error during profile update.' });
    }
});

app.post('/api/logout', async (req, res) => {
    const { userId, cart } = req.session;
    if (userId) await updateUserCartInDb(userId, cart || {});
    req.session.destroy(err => {
        if (err) return res.status(500).json({ message: 'Could not log out.' });
        res.clearCookie('connect.sid');
        res.json({ success: true, message: 'Logged out successfully.' });
    });
});

app.get('/api/session', (req, res) => {
    if (req.session.userId) {
        res.json({ isLoggedIn: true, username: req.session.username, email: req.session.email, cart: req.session.cart || {} });
    } else {
        res.json({ isLoggedIn: false, cart: {} });
    }
});

app.post('/api/orders/create', async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ message: 'You must be logged in to place an order.' });
    const cart = req.session.cart || {};
    const productIds = Object.keys(cart);
    if (productIds.length === 0) return res.status(400).json({ message: 'Your cart is empty.' });
    try {
        const placeholders = productIds.map(() => '?').join(',');
        const productsFromDb = await dbAll(`SELECT id, price, discount FROM products WHERE id IN (${placeholders})`, productIds);
        let totalAmount = 0;
        productsFromDb.forEach(p => {
            const quantity = cart[p.id];
            const discountedPrice = p.price * (1 - p.discount / 100);
            totalAmount += discountedPrice * quantity;
        });
        const amountInPaise = Math.round(totalAmount * 100);
        const options = { amount: amountInPaise, currency: 'INR', receipt: `receipt_${req.session.userId}_${Date.now()}` };
        const order = await razorpay.orders.create(options);
        res.json({ success: true, order, key: RAZORPAY_KEY_ID });
    } catch (error) {
        console.error("Create Order Error:", error);
        res.status(500).json({ message: 'Server error during order creation.' });
    }
});

app.post('/api/orders/verify', async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ message: 'Authentication failed.' });
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, recipientDetails } = req.body;
    const body = `${razorpay_order_id}|${razorpay_payment_id}`;
    const expectedSignature = crypto.createHmac('sha256', RAZORPAY_KEY_SECRET).update(body.toString()).digest('hex');
    if (expectedSignature !== razorpay_signature) return res.status(400).json({ success: false, message: 'Payment verification failed.' });
    try {
        const orderDetails = await razorpay.orders.fetch(razorpay_order_id);
        const amountInPaise = orderDetails.amount;
        const cart = req.session.cart || {};
        const productIds = Object.keys(cart);
        const placeholders = productIds.map(() => '?').join(',');
        const productsFromDb = await dbAll(`SELECT id, name, price, discount, image FROM products WHERE id IN (${placeholders})`, productIds);
        const productDetails = productsFromDb.map(p => ({ id: p.id, name: p.name, quantity: cart[p.id], pricePerItem: p.price * (1 - p.discount / 100), image: p.image }));
        await dbRun(
            `INSERT INTO orders (user_id, razorpay_order_id, razorpay_payment_id, razorpay_signature, amount_in_paise, recipient_details, product_details) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [req.session.userId, razorpay_order_id, razorpay_payment_id, razorpay_signature, amountInPaise, JSON.stringify(recipientDetails), JSON.stringify(productDetails)]
        );
        req.session.cart = {};
        await updateUserCartInDb(req.session.userId, {});
        res.json({ success: true, message: 'Payment successful and order placed!' });
    } catch (error) {
        console.error('Order Saving Error:', error);
        res.status(500).json({ success: false, message: 'Server error while saving the order.' });
    }
});

app.get('/api/orders/my-orders', async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ message: 'You must be logged in to view your orders.' });
    try {
        const orders = await dbAll('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC', [req.session.userId]);
        res.json({ success: true, orders });
    } catch (error) {
        res.status(500).json({ message: 'Server error while fetching orders.' });
    }
});


// --- ADMIN-SPECIFIC ROUTES ---
const isAdmin = (req, res, next) => {
    if (req.session.isAdmin) return next();
    res.status(403).json({ success: false, message: 'Access denied. Administrator privileges required.' });
};

app.post('/admin/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const admin = await dbGet('SELECT * FROM admin WHERE username = ?', [username]);
        if (!admin) return res.status(401).json({ success: false, message: 'Invalid credentials.' });
        const isMatch = await bcrypt.compare(password, admin.password);
        if (isMatch) {
            req.session.isAdmin = true;
            res.status(200).json({ success: true, message: 'Admin login successful.' });
        } else {
            res.status(401).json({ success: false, message: 'Invalid credentials.' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error during admin login.' });
    }
});

app.get('/admin/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) return res.status(500).json({ success: false, message: 'Could not log out.' });
        res.clearCookie('connect.sid');
        res.status(200).json({ success: true, message: 'Logged out successfully.' });
    });
});

app.get('/admin/session', (req, res) => {
    res.status(200).json({ isAdmin: !!req.session.isAdmin });
});

app.get('/admin/orders', isAdmin, async (req, res) => {
    try {
        const orders = await dbAll('SELECT * FROM orders ORDER BY created_at DESC');
        res.status(200).json({ success: true, orders });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error fetching orders.' });
    }
});

app.post('/admin/orders/update-tracking', isAdmin, async (req, res) => {
    const { orderId, trackingLink } = req.body;
    try {
        await dbRun('UPDATE orders SET tracking_link = ? WHERE id = ?', [trackingLink, orderId]);
        res.status(200).json({ success: true, message: 'Tracking link updated.' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error updating tracking link.' });
    }
});

app.post('/admin/orders/update-status', isAdmin, async (req, res) => {
    const { orderId, status } = req.body;
    const allowedStatuses = ['paid', 'delivered'];
    if (!allowedStatuses.includes(status)) return res.status(400).json({ success: false, message: 'Invalid status provided.' });
    try {
        await dbRun('UPDATE orders SET status = ? WHERE id = ?', [status, orderId]);
        res.status(200).json({ success: true, message: 'Order status updated.' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error updating status.' });
    }
});


// --- PAGE SERVING ROUTES ---
app.get('/', (_, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/shop', (_, res) => res.sendFile(path.join(__dirname, 'public', 'shop.html')));
app.get('/products/:id', (_, res) => res.sendFile(path.join(__dirname, 'public', 'product.html')));
app.get('/orders', (_, res) => res.sendFile(path.join(__dirname, 'public', 'orders.html')));
app.get('/admin', (_, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));


// --- START SERVER ---
app.listen(PORT, () => console.log(`🚀 Micky Money server running at http://localhost:${PORT}`));

